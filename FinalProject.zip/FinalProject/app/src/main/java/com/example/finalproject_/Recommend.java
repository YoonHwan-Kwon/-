package com.example.finalproject_;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class Recommend extends Activity {

    Button Cal;
    EditText edt1, edt2;
    TextView BResult;
    String num1, num2;//몸무게 키 저장할 변수 2개 string
    Integer result;//합산 결과를 저장할 변수 선언
    Double temp;
    String temp2;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend2);

        Cal = (Button)findViewById(R.id.Cal);
        edt1 = (EditText)findViewById(R.id.edt1);
        edt2 = (EditText)findViewById(R.id.edt2);
        BResult = (TextView)findViewById(R.id.BResult);

        Cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1=edt1.getText().toString();
                num2=edt2.getText().toString();
                temp=Double.parseDouble(num1)/Double.parseDouble(num2)/Double.parseDouble(num2)*10000;
                temp2=String.format("%.2f", temp);
                BResult.setText("당신의 BMI : "+ temp2);

            }
        });
    }
}
