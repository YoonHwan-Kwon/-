package com.example.finalproject_;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class Muscle extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.muscle);
    }
}
