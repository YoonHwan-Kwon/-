package com.example.finalproject_;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;

public class Choose extends Activity {
     Button mainBtn1, mainBtn2, mainBtn3, mainBtn4;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose);    //choose.xml 화면

        mainBtn1 = (Button)findViewById(R.id.mainBtn1);
        mainBtn2 = (Button)findViewById(R.id.mainBtn2);
        mainBtn3 = (Button)findViewById(R.id.mainBtn3);
        mainBtn4 = (Button)findViewById(R.id.mainBtn4);
        //버튼 클릭시 diet화면으로 이동
        mainBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Diet.class) ;

                startActivity(intent);//diet 화면 시작
            }
        });  //main1
        mainBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Muscle.class);

                startActivity(intent);
            }
        }); //main2
        mainBtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Part.class);

                startActivity(intent);
            }
        }); //main3
        mainBtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Recommend.class);

                startActivity(intent);
            }
        });
    }
}
