package com.example.finalproject_;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;

public class Diet extends Activity {

    Button diet1, diet2, diet3, diet4, diet5;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diet);
        diet1 = findViewById(R.id.diet1);
        diet2 = findViewById(R.id.diet2);
        diet3 = findViewById(R.id.diet3);
        diet4 = findViewById(R.id.diet4);
        diet5 = findViewById(R.id.diet5);

        diet1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=lFiB5A1eGWM"));
                startActivity(urlintent);
            }
        });

        diet2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=A3fFpNkBu4o"));
                startActivity(urlintent);
            }
        });

        diet3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=RkmSLsiQkdw"));
                startActivity(urlintent);
            }
        });

        diet4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=ghclqJxl8AU&t=153s"));
                startActivity(urlintent);
            }
        });

        diet5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=Zq8nRY9P_cM&t=76s"));
                startActivity(urlintent);
            }
        });
    }


}
