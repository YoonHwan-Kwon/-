package com.example.finalproject_;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Join extends Activity {

    EditText joinID, joinPW, joinName, joinAge, joinHeight, joinWeight;
    RadioButton joinMale, joinFemale;
    Button joinJoin;
    SQLiteDatabase sqlDB;
    myDBHelper myHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join);  //join.xml을 화면에 셋팅

        joinID = (EditText) findViewById(R.id.joinID);
        joinPW = (EditText) findViewById(R.id.joinPW);
        joinName = (EditText) findViewById(R.id.joinName);
        joinAge = (EditText) findViewById(R.id.joinAge);
        joinHeight = (EditText) findViewById(R.id.joinHeight);
        joinWeight = (EditText) findViewById(R.id.joinWeight);
        joinMale = (RadioButton) findViewById(R.id.joinMale);
        joinFemale = (RadioButton) findViewById(R.id.joinFemale);
        joinJoin = (Button) findViewById(R.id.joinJoin);
        myHelper = new myDBHelper(this);

        joinJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sqlDB = myHelper.getWritableDatabase();
                sqlDB.execSQL("INSERT INTO Join_info VALUES ('" + joinID.getText().toString() + "','" +
                        joinPW.getText().toString() + "');");
                sqlDB.close();
                //가입완료시 토스트 메시지로 안내 멘트 및 메인화면으로 이동
                Toast.makeText(getApplicationContext(), "회원가입이 완료되었습니다.", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });//joinJoin

    }//onCreate()

    public class myDBHelper extends SQLiteOpenHelper {
        public myDBHelper(Context context) {
            super(context, "LoginDB", null, 1); //생성자로 LoginDB생성
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE Join_info(uId TEXT, uPassword TEXT);");
        }//onCreate

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS Join_info");
            onCreate(db);
        }//onUpgrade
    }//myDBHelper
}//Join()
