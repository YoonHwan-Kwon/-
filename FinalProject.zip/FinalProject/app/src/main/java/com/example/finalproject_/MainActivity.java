package com.example.finalproject_;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Join {    //join.java를 상속받아서 사용

    EditText mainID, mainPW;
    Button mainLogin, mainJoin;
    int IDFlag = 0;
    int PWFlag = 0;   //메인에서 ID, PW를 입력하면 DB의 등록된 ID와 PW가 일치하면 1, 불일치 0 저장용

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainID = (EditText) findViewById(R.id.mainID);
        mainPW = (EditText) findViewById(R.id.mainPW);
        mainLogin = (Button) findViewById(R.id.mainLogin);
        mainJoin = (Button) findViewById(R.id.mainJoin);

        //mainJoin 회원가입 화면으로 이동
        mainJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Join.class);
                startActivity(intent);
            }
        });//mainJoin

        mainLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor;  //가입된 Join_info 테이블의 회원정보를 받음
                sqlDB = myHelper.getReadableDatabase();
                cursor = sqlDB.rawQuery("SELECT * FROM Join_info;", null);

                String edt1 = null; //화면에서 EditText에서 입력한 ID를 저장할 임시변수
                String edt2 = null; //PW
                String pass1 = null;    //데이터베이스에 등록된 회원 ID를 저장할 변수
                String pass2 = null;    //PW

                IDFlag = 0;
                PWFlag = 0;

                while (cursor.moveToNext()) {
                    edt2 = cursor.getString(0);
                    pass2 = cursor.getString(1);    //DB의 정보를 임시변수에 저장
                    edt1 = mainID.getText().toString();
                    pass1 = mainPW.getText().toString();    //화면의 정보를 임시변수에 저장

                    if (edt2.equals(edt1)) { //아이디가 테이블에 저장한 ID와 일치여부 비교
                        IDFlag = 1; //일치시 플래그변수에 일치 1 저장, 불일치는 0 저장

                        if (pass2.equals(pass1)) {
                            PWFlag = 1;
                            //아이디와 패스워드가 둘 다 일치 했을때 안내 멘트 및 화면이동
                            Toast.makeText(getApplicationContext(), "로그인 되었습니다.", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(getApplicationContext(), Choose.class);
                            startActivity(intent);
                        }//if_PW
                        else {   //PW 불일치 안내 멘트
                            Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_LONG).show();
                        }//else_PW

                    }//if_ID
                    else {

                    }//else_ID
                }//while
                cursor.close();
                sqlDB.close();

                if (IDFlag == 0 && PWFlag == 0) { //ID 불일치 안내멘트
                    Toast.makeText(getApplicationContext(), "존재하지 않는 회원입니다. 아이디를 다시 확인해주세요.", Toast.LENGTH_LONG).show();
                }//if

            }//onClick
        });//mainLogin

    }//onCreate
}//Main